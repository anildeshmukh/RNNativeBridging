import React, { useState } from 'react';
import { 
    StyleSheet, 
    Button, 
    View, 
    SafeAreaView, 
    Text, 
    Image
} from 'react-native';

import { CaptureImage } from './src/NativeBriding/Camera/CaptureImage';

const [imgUrl, setImgUrl] = useState();

const onCaptureImage = () => {
    CaptureImage.imageCapture((bitMap)=> {
      setImgUrl(bitMap);
    });
}

const Root = () => (
  <SafeAreaView style={styles.container}>
    <View>
      <Text style={styles.title}>
        Get Image from Native Camera and send back to JS layer
      </Text>
      <Button
        title="Capture Picture"
        onPress={onCaptureImage}
      />
      {!!imgUrl && <Image uri={imgUrl} />}
    </View>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 16,
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
});

export default Root;