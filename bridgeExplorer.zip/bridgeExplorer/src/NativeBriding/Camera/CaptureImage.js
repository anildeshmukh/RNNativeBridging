
 import { NativeModules } from "react-native";

 /**
  * Native definition and export
  */
 
 // Use Native Code directly
 
 export const CaptureImage = NativeModules.CaptureImage;
 
 