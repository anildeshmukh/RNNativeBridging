
const React = require('react-native');
const invariant = require('invariant');

const NativeModules = React.NativeModules;
const Platform = React.Platform;
const NativeCaptureImageAndroid = NativeModules.CaptureImage;

 /**
  * Native definition and export
  */
 
let CaptureImage;
if (Platform.OS === 'ios') {
  
} else if (Platform.OS === 'android') {
  invariant(NativeCaptureImageAndroid, 'Run react-native run-android');
  CaptureImage = NativeCaptureImageAndroid;
} else {
  invariant(CaptureImage, 'Invalid platform');
}


module.exports = {
    imageCapture() {
        return CaptureImage.imageCapture();
  }
};
